#include <stdio.h>

int main(int argc, char *argv[]) {
  puts("hello world!");
  return 0;
}
