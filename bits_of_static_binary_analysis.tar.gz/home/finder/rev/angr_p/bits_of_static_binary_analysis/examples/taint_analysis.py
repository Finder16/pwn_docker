import os

from angr import Project
from angr.analyses.reaching_definitions.dep_graph import DepGraph
from angr.knowledge_plugins.key_definitions.atoms import Atom
from angr.procedures.definitions.glibc import _libc_decls
from angr.knowledge_plugins.key_definitions.constants import OP_BEFORE
from angr.analyses.reaching_definitions.function_handler import FunctionHandler

# Local handy function to pricommand_line_injectionnt a graph to a file.
from utils import magic_graph_print as m_g_p

class TaintHandler(FunctionHandler):
    """
    A mechanism for summarizing a function call's effect on a program for ReachingDefinitionsAnalysis.
    """

    def __init__(self, interfunction_level: int = 3):
        self.interfunction_level: int = interfunction_level


    def hook(self, analysis: "ReachingDefinitionsAnalysis") -> "FunctionHandler":
        """
        Attach this instance of the function handler to an instance of RDA.
        """
        return self


    def handle_local_function(self, state, data):
        #import ipdb; ipdb.set_trace() 
        super().handle_local_function(state, data)
        print("function name : ", data.name)
        print("function address : ", hex(data.address))
        print()

        return True, state, 


magic_graph_print = lambda dependencies: m_g_p(os.path.basename(__file__)[:-3], dependencies)

project = Project('../build/command_line_injection', auto_load_libs=False)
cfg = project.analyses.CFGFast(normalize=True, data_references=True)

_ = project.analyses.CompleteCallingConventions(recover_variables=True)

rdi_offset = project.arch.registers['rdi'][0]

sink_name = 'system'
sink_function = project.kb.functions.function(name=sink_name)

# We know that it is the first parameter of `system` that is "vulnerable".
parameter_position = 0
# `angr` has a bunch of pre-declared information about libc functions.
parameter_type = _libc_decls[sink_name].args[parameter_position]

parameter_atom = Atom.reg("rdi", arch=project.arch)

vulnerable_atoms_and_types = [(parameter_atom, parameter_type)]

observation_point = ('insn', sink_function.addr, OP_BEFORE)

handler = TaintHandler(interfunction_level=5)


main_function = project.kb.functions.function(name='main')
program_rda = project.analyses.ReachingDefinitions(
    subject=main_function,
    function_handler = handler,
    observe_all=True,
    track_tmps=True, 
    track_liveness= True,
    observation_points = [observation_point],
    dep_graph=True
)
#rdi_definition = [x for x in program_rda.observed_results[observation_point].get_register_definitions(rdi_offset, 8)][0]
rdi_def = [x for x in program_rda.get_reaching_definitions(sink_function.addr, OP_BEFORE).get_definitions_from_atoms([parameter_atom])][0]
rdi_dependencies = program_rda.dep_graph.transitive_closure(rdi_def)

# Let's print to a file, so we can look at it.
# ** Something went wrong here **
#magic_graph_print(rdi_dependencies)
