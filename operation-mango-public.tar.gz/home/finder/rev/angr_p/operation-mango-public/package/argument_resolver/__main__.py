from argument_resolver.analysis.mango import main

main()
