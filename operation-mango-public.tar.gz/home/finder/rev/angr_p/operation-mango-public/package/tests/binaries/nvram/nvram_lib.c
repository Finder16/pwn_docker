
void acosNvramConfig_set(char *key, char *value) {}

char* acosNvramConfig_get(char *key) {
    return "echo 'HELLO WORLD'";
}
