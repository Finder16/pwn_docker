/* nvram_lib.h */
extern char* acosNvramConfig_get(char *);
extern void acosNvramConfig_set(char *, char *);
